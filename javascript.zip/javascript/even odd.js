console.log("check a number is even or odd")
let n=7
if(n%2==0){
    console.log("given number is even:",n)
}
else{
    console.log("given number is odd:",n)
}