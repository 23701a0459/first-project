console.log("checking the number is positive,negative or zero")
let n=+5
if(n>0){
    console.log(" given number is positive")
}
else if(n<0){
    console.log(" given number is negative")
}
else{
    console.log("zero")
}