console.log("checking pass or fail")
let n=36
if(n<=33){
    console.log("student is failed")
}
else{
    console.log("student is passed")
}