console.log("assigning a grades")
let n=85
if(n>=90){
    console.log("grade A")
}
else if(n>=80){
    console.log("grade b")
}
else if(n>=60){
    console.log("grade c")
}
else{
    console.log("grade d")
}