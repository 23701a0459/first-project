console.log("checking eligibility for voting")
let n=21
if(n<18){
    console.log("you cannot vote")
}
else{
    console.log("you can vote" )
}